MovieWp theme by FlexiThemes, https://flexithemes.com
Online Demo: https://flexithemes.com/demo/MovieWp/
Theme URI: https://flexithemes.com/moviewp-wordpress-theme/